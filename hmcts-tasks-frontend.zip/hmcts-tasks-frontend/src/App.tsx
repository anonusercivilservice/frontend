import React, { useEffect, useState } from 'react';
import type { Task, TaskStatus } from './types/Task';
import { fetchTasks, createTask, updateTaskStatus, deleteTask } from './api/tasksApi';
import { TaskForm } from './components/TaskForm';
import { TaskList } from './components/TaskList';

export const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchTasks();
      setTasks(data);
    } catch (err: any) {
      setError(err.message ?? 'Failed to load tasks');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async (input: {
    title: string;
    description?: string;
    status: TaskStatus;
    dueDateTime: string;
  }) => {
    setError(null);
    const newTask = await createTask(input);
    setTasks(current => [...current, newTask]);
  };

  const handleChangeStatus = async (id: string, status: TaskStatus) => {
    setError(null);
    try {
      const updated = await updateTaskStatus(id, status);
      setTasks(current => current.map(t => (t.id === id ? updated : t)));
    } catch (err: any) {
      setError(err.message ?? 'Failed to update status');
      await load();
    }
  };

  const handleDelete = async (id: string) => {
    setError(null);
    try {
      await deleteTask(id);
      setTasks(current => current.filter(t => t.id !== id));
    } catch (err: any) {
      setError(err.message ?? 'Failed to delete task');
    }
  };

  return (
    <div className="app">
      <header>
        <h1>Caseworker task manager</h1>
      </header>
      {error && <div className="error-banner">{error}</div>}
      {loading ? (
        <p>Loading tasks…</p>
      ) : (
        <div className="layout">
          <TaskForm onSubmit={handleCreate} />
          <TaskList
            tasks={tasks}
            onChangeStatus={handleChangeStatus}
            onDelete={handleDelete}
          />
        </div>
      )}
    </div>
  );
};
