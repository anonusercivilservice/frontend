import React, { useState } from 'react';
import type { TaskStatus } from '../types/Task';

interface Props {
  onSubmit(task: {
    title: string;
    description?: string;
    status: TaskStatus;
    dueDateTime: string;
  }): Promise<void>;
}

export const TaskForm: React.FC<Props> = ({ onSubmit }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<TaskStatus>('TODO');
  const [dueDateTime, setDueDateTime] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim() || !dueDateTime) {
      setError('Title and due date/time are required');
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit({
        title: title.trim(),
        description: description.trim() || undefined,
        status,
        dueDateTime: new Date(dueDateTime).toISOString()
      });
      setTitle('');
      setDescription('');
      setStatus('TODO');
      setDueDateTime('');
    } catch (err: any) {
      setError(err.message ?? 'Failed to create task');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <h2>Create task</h2>
      {error && <div className="error">{error}</div>}

      <div className="form-group">
        <label htmlFor="title">Title *</label>
        <input
          id="title"
          value={title}
          onChange={e => setTitle(e.target.value)}
          maxLength={200}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="description">Description (optional)</label>
        <textarea
          id="description"
          value={description}
          onChange={e => setDescription(e.target.value)}
          maxLength={4000}
        />
      </div>

      <div className="form-group">
        <label htmlFor="status">Status *</label>
        <select
          id="status"
          value={status}
          onChange={e => setStatus(e.target.value as TaskStatus)}
        >
          <option value="TODO">To do</option>
          <option value="IN_PROGRESS">In progress</option>
          <option value="DONE">Done</option>
          <option value="BLOCKED">Blocked</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="dueDateTime">Due date/time *</label>
        <input
          id="dueDateTime"
          type="datetime-local"
          value={dueDateTime}
          onChange={e => setDueDateTime(e.target.value)}
          required
        />
      </div>

      <button type="submit" disabled={submitting}>
        {submitting ? 'Creating…' : 'Create task'}
      </button>
    </form>
  );
};
