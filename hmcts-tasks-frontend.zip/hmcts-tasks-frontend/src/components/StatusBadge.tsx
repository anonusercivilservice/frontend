import React from 'react';
import type { TaskStatus } from '../types/Task';

const labels: Record<TaskStatus, string> = {
  TODO: 'To do',
  IN_PROGRESS: 'In progress',
  DONE: 'Done',
  BLOCKED: 'Blocked'
};

export const StatusBadge: React.FC<{ status: TaskStatus }> = ({ status }) => (
  <span className={`status-badge status-badge--${status.toLowerCase()}`}>
    {labels[status]}
  </span>
);
