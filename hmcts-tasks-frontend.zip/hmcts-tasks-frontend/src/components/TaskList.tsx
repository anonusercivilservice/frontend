import React from 'react';
import type { Task, TaskStatus } from '../types/Task';
import { StatusBadge } from './StatusBadge';

interface Props {
  tasks: Task[];
  onChangeStatus(id: string, status: TaskStatus): Promise<void>;
  onDelete(id: string): Promise<void>;
}

export const TaskList: React.FC<Props> = ({ tasks, onChangeStatus, onDelete }) => {
  const handleStatusChange =
    (id: string) => (e: React.ChangeEvent<HTMLSelectElement>) =>
      onChangeStatus(id, e.target.value as TaskStatus);

  return (
    <div className="task-list">
      <h2>Tasks</h2>
      {tasks.length === 0 && <p>No tasks yet.</p>}

      {tasks.map(task => (
        <article key={task.id} className="task-card">
          <header className="task-card__header">
            <h3>{task.title}</h3>
            <StatusBadge status={task.status} />
          </header>
          {task.description && (
            <p className="task-card__description">{task.description}</p>
          )}
          <dl className="task-card__meta">
            <div>
              <dt>Due</dt>
              <dd>{new Date(task.dueDateTime).toLocaleString()}</dd>
            </div>
            <div>
              <dt>Created</dt>
              <dd>{new Date(task.createdAt).toLocaleString()}</dd>
            </div>
          </dl>
          <footer className="task-card__footer">
            <label>
              Status:{' '}
              <select
                value={task.status}
                onChange={handleStatusChange(task.id)}
              >
                <option value="TODO">To do</option>
                <option value="IN_PROGRESS">In progress</option>
                <option value="DONE">Done</option>
                <option value="BLOCKED">Blocked</option>
              </select>
            </label>
            <button
              type="button"
              className="danger"
              onClick={() => onDelete(task.id)}
            >
              Delete
            </button>
          </footer>
        </article>
      ))}
    </div>
  );
};
