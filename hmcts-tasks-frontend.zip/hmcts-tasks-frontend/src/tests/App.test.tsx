import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { App } from '../App';

vi.mock('../api/tasksApi', () => ({
  fetchTasks: vi.fn().mockResolvedValue([]),
  createTask: vi.fn(),
  updateTaskStatus: vi.fn(),
  deleteTask: vi.fn()
}));

describe('App', () => {
  it('renders heading', async () => {
    render(<App />);
    expect(await screen.findByText(/Caseworker task manager/i)).toBeInTheDocument();
  });
});
